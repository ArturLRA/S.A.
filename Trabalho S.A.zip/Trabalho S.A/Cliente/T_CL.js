    function cadastrar() {
    let nomeCadastro =  document.getElementById('nome').value;
    let emailCadastro = document.getElementById('email').value;
    let senhaCadastro =  document.getElementById('senha').value;
    let confirmarSenhaCadastro =  document.getElementById('confirmarSenha').value;

    if(senhaCadastro == confirmarSenhaCadastro){
        alert("meu pau de orcolos")
        let loginsUsuarios = JSON.parse(localStorage.getItem("CadastroUsuarios")) || {};
        
        if(loginsUsuarios[emailCadastro]){
            alert("Nome de Usuário já cadastrado")
            return;
        }

        loginsUsuarios[emailCadastro] = {
            nomeCadastrado: nomeCadastro,
            emailCadastrado: emailCadastro,
            senhaCadastrada: senhaCadastro
        }

        localStorage.setItem('CadastroUsuarios', JSON.stringify(loginsUsuarios))

        alert('usuario cadstrado com sucesso')
    }
    else{
        alert("as senhas estão diferentes")
    }

}

function login() {
    let nomeLogin =  document.getElementById('nome').value;
    let emailLogin = document.getElementById('email').value;
    let senhaLogin =  document.getElementById('senha').value;

    let login = JSON.parse(localStorage.getItem('emailCadastro'))

if(nomeLogin == [emailCadastro] && emailLogin == [emailCadastro] && senhaLogin == [emailCadastro]){
    alert('logado')
}
else{
    alert('voce nao esta cadastrado')
}
}